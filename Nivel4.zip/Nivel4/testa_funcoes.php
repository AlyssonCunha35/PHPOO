<?php

require 'db/pessoa_db.php';


echo  '<pre>';
print_r( get_next_pessoa() );
